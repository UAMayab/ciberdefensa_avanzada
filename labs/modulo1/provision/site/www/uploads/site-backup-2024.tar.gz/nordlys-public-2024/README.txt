Arkiv af det gamle offentlige site (theme 1.4.2), taget 2025-10-02
inden omlaegningen til Hugo + nordlys-theme 2.x.

Indhold:
  config/settings.ini   konfiguration inkl. legacy-credentials
  public/               statiske sider fra det gamle site

Arkivet kan slettes, nar vi er sikre pa, at ingen sider mangler
i det nye site (NOR-1493). Kontakt: jonas.bak@nordlysai.dk
